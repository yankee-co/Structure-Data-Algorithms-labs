#ifndef M1_H_INCLUDED
#define M1_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

void S1();
void S2();
void S3();

#endif

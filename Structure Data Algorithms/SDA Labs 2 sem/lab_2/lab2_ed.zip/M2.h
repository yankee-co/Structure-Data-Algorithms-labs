#ifndef M2_H_INCLUDED
#define M2_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

void S4();
void S8();

#endif

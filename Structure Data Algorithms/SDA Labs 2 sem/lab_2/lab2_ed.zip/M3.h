#ifndef M3_H_INCLUDED
#define M3_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

void S5();
void S6();
void S7();

#endif

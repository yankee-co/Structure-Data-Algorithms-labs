#include <stdlib.h>
#include <stdio.h>
#include "common.h"

void MErr(void){
    fprintf(logs, "MErr triggered\n");
}
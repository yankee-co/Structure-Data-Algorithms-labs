#ifndef COMMON_H_INCLUDED
#define COMMON_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

typedef int Tg1, Tg2, Tg3, Tg4, Tg5;
extern int Vg1, Vg2, counter;
extern int const Cg1, Cg2, Cg3;
extern FILE *logs;

void common_init();

#endif

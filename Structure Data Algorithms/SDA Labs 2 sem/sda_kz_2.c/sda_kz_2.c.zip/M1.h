#ifndef M1_H_INCLUDED
#define M1_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

void F1_1();
void F1_2();

#endif

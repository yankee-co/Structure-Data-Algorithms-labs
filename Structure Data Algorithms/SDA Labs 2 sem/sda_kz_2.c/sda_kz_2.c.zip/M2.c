#include <stdio.h>
#include <stdlib.h>
#include "common.h"

void F2(void){

    fprintf(logs, "F2 started\n");
    // body
    fprintf(logs, "F2 finished\n");

}



#ifndef M2_H_INCLUDED
#define M2_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

void F2();

#endif

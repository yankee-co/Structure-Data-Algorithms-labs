#include <stdio.h>
#include <stdlib.h>
#include "common.h"

void F3(void){

    fprintf(logs, "F3 started\n");
    // F3 body
    fprintf(logs, "F3 finished\n");

}
